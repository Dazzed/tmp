package com.delta.cru.unttest.cnfg;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CmnCnfgTest.class, CnfgReaderTest.class, SwaggerCnfgTest.class })
public class CnfgTestSuite {

}