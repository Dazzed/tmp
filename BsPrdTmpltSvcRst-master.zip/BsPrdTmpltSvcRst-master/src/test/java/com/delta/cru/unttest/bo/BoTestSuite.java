package com.delta.cru.unttest.bo;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ EmpDtlsBoImplTest.class,EmpSPDtlsBoImplTest.class })
public class BoTestSuite {

}
