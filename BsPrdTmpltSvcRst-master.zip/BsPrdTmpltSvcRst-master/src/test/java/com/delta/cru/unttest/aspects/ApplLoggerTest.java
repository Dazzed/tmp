/**
 * 
 */
package com.delta.cru.unttest.aspects;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.delta.cru.aspects.ApplLogger;

//ADD TEST CASES FOR CUSTOMIZED LOGGING IN THIS FILE

/**
 * @author z73790
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class ApplLoggerTest {
	
	@InjectMocks
	ApplLogger applLogger;

	@Test
	public void test() {

	}

}
