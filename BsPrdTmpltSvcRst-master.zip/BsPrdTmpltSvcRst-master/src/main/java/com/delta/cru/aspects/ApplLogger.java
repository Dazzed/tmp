package com.delta.cru.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

// ADD CUSTOMIZED LOGGING IN THIS FILE

@Aspect
@Component
public class ApplLogger {

}
